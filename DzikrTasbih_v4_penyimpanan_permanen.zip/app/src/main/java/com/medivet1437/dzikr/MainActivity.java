package com.medivet1437.dzikr;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private EditText nameInput, dhikrTextInput, targetInput;
    private TextView countText, speedText, remainingText, estimateText, finishText, statusText;
    private long count = 0, target = 1000, lastTap = 0;
    private final ArrayDeque<Long> intervals = new ArrayDeque<>();
    private android.content.SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable updater = new Runnable() {
        public void run() { updateStats(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("dzikr_data", MODE_PRIVATE);
        nameInput = findViewById(R.id.nameInput);
        dhikrTextInput = findViewById(R.id.dhikrTextInput);
        targetInput = findViewById(R.id.targetInput);
        countText = findViewById(R.id.countText);
        speedText = findViewById(R.id.speedText);
        remainingText = findViewById(R.id.remainingText);
        estimateText = findViewById(R.id.estimateText);
        finishText = findViewById(R.id.finishText);
        statusText = findViewById(R.id.statusText);

        loadSaved();

        findViewById(R.id.tapArea).setOnClickListener(v -> registerTap());
        findViewById(R.id.minusButton).setOnClickListener(v -> {
            if (count > 0) { count--; saveData(); updateStats(); }
        });
        findViewById(R.id.resetButton).setOnClickListener(v -> confirmReset());
        findViewById(R.id.saveButton).setOnClickListener(v -> {
            readTarget();
            saveData();
            updateStats();
            statusText.setText("Tersimpan otomatis");
        });
        findViewById(R.id.newDhikrButton).setOnClickListener(v -> newDhikr());

        handler.post(updater);
    }

    private void loadSaved() {
        nameInput.setText(prefs.getString("name", ""));
        dhikrTextInput.setText(prefs.getString("text", ""));
        target = prefs.getLong("target", 1000);
        count = prefs.getLong("count", 0);
        targetInput.setText(String.valueOf(target));
        statusText.setText(count > 0 ? "Dilanjutkan dari hitungan tersimpan" : "Hitungan tersimpan otomatis");
        updateStats();
    }

    private void readTarget() {
        try {
            long n = Long.parseLong(targetInput.getText().toString().trim());
            if (n > 0) target = n;
        } catch (Exception ignored) {}
    }

    private void saveData() {
        readTarget();
        prefs.edit()
            .putString("name", nameInput.getText().toString())
            .putString("text", dhikrTextInput.getText().toString())
            .putLong("target", target)
            .putLong("count", count)
            .commit();
    }

    private void registerTap() {
        readTarget();
        if (count >= target) return;
        long now = System.currentTimeMillis();
        if (lastTap > 0) {
            long d = now - lastTap;
            if (d >= 150 && d <= 10000) {
                intervals.addLast(d);
                while (intervals.size() > 30) intervals.removeFirst();
            }
        }
        lastTap = now;
        count++;
        saveData();
        try {
            ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE))
                .vibrate(android.os.VibrationEffect.createOneShot(18, 45));
        } catch (Exception ignored) {}
        updateStats();
    }

    private double getKpm() {
        if (intervals.isEmpty()) return 0;
        double sum = 0;
        for (long x : intervals) sum += x;
        return 60000.0 / (sum / intervals.size());
    }

    private void updateStats() {
        countText.setText(String.format(Locale.US, "%,d / %,d", count, target));
        long rem = Math.max(0, target - count);
        remainingText.setText("Sisa: " + String.format(Locale.US, "%,d", rem));

        double kpm = getKpm();
        if (rem == 0) {
            speedText.setText("Target tercapai");
            estimateText.setText("TARGET SELESAI");
            finishText.setText("Alhamdulillah");
        } else if (kpm <= 0) {
            speedText.setText("Kecepatan: -- ketukan/menit");
            estimateText.setText("Estimasi: mulai mengetuk");
            finishText.setText("Selesai sekitar: --:--");
        } else {
            speedText.setText(String.format(Locale.US, "Kecepatan: %.1f ketukan/menit", kpm));
            long sec = Math.round((rem / kpm) * 60.0);
            estimateText.setText("Estimasi tersisa: " + formatDuration(sec));
            Calendar c = Calendar.getInstance();
            c.add(Calendar.SECOND, (int)Math.min(sec, 2147483647L));
            finishText.setText("Selesai sekitar: " +
                new SimpleDateFormat("HH:mm", Locale.getDefault()).format(c.getTime()));
        }
    }

    private String formatDuration(long sec) {
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return h + " jam " + m + " menit";
        if (m > 0) return m + " menit " + s + " detik";
        return s + " detik";
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("Reset hitungan?")
            .setMessage("Jumlah dzikir akan kembali ke 0. Teks dan target tetap disimpan.")
            .setPositiveButton("Reset", (d,w) -> {
                count = 0; lastTap = 0; intervals.clear(); saveData(); updateStats();
            })
            .setNegativeButton("Batal", null).show();
    }

    private void newDhikr() {
        new AlertDialog.Builder(this)
            .setTitle("Dzikir Baru")
            .setMessage("Hitungan akan direset. Teks dan target lama akan diganti setelah Anda mengeditnya.")
            .setPositiveButton("Lanjut", (d,w) -> {
                count = 0; lastTap = 0; intervals.clear();
                nameInput.setText("");
                dhikrTextInput.setText("");
                targetInput.setText("1000");
                target = 1000;
                saveData(); updateStats();
                nameInput.requestFocus();
                ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                    .showSoftInput(nameInput, InputMethodManager.SHOW_IMPLICIT);
            })
            .setNegativeButton("Batal", null).show();
    }

    @Override protected void onPause() {
        saveData();
        super.onPause();
    }

    @Override protected void onStop() {
        // Commit synchronously so the latest count is on disk before the activity stops.
        saveData();
        super.onStop();
    }

    @Override protected void onDestroy() {
        saveData();
        handler.removeCallbacks(updater);
        super.onDestroy();
    }
}
