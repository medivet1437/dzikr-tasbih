# Dzikr Tasbih Android

Versi 1 aplikasi tasbih touchscreen offline.

Fitur:
- ketuk seluruh area untuk menghitung dzikir
- target dapat diubah
- KPM otomatis dari rata-rata hingga 30 interval ketukan terakhir
- estimasi waktu tersisa
- estimasi jam selesai
- tombol kurang 1 dan reset
- getaran singkat setiap ketukan
- layar tetap menyala

## Build
Buka folder ini di Android Studio terbaru, tunggu Gradle sync, lalu:
Build > Build APK(s)

APK debug biasanya berada di:
app/build/outputs/apk/debug/app-debug.apk


## Versi 2.0 – penyimpanan permanen diperkuat
- Hitungan disimpan setiap ketukan dengan `SharedPreferences.commit()`.
- Data juga disimpan pada `onPause`, `onStop`, dan `onDestroy`.
- Target, judul dzikir, dan teks dzikir ikut disimpan.
- Menutup dan membuka kembali aplikasi tidak mengulang hitungan.
- Versi aplikasi: 2.0.
