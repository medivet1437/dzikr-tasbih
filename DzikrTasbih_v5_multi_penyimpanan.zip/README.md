# Dzikr Tasbih V5

Aplikasi penghitung dzikir dengan **multi penyimpanan dzikir**.

Fitur:
- Banyak dzikir dalam satu aplikasi.
- Setiap dzikir memiliki nama, teks, target, dan hitungan sendiri.
- Hitungan tersimpan otomatis di HP.
- Bisa berganti dzikir dan melanjutkan hitungan kapan saja.
- Menutup aplikasi tidak mengembalikan hitungan ke 0.
- Data V4 satu-dzikir dimigrasikan otomatis menjadi dzikir pertama.
- Logo MDS tetap digunakan.
