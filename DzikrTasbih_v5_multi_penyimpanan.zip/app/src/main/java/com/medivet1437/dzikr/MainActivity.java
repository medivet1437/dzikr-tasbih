package com.medivet1437.dzikr;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private EditText nameInput, dhikrTextInput, targetInput;
    private TextView countText, speedText, remainingText, estimateText, finishText, statusText, currentTitle;
    private LinearLayout listContainer;
    private long count = 0, target = 1000, lastTap = 0;
    private final ArrayDeque<Long> intervals = new ArrayDeque<>();
    private final ArrayList<Dhikr> items = new ArrayList<>();
    private int selectedIndex = -1;
    private android.content.SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable updater = new Runnable() {
        public void run() { updateStats(); handler.postDelayed(this, 1000); }
    };

    private static class Dhikr {
        String id, name, text;
        long target, count;
        Dhikr(String id, String name, String text, long target, long count) {
            this.id=id; this.name=name; this.text=text; this.target=target; this.count=count;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("dzikr_data", MODE_PRIVATE);
        nameInput = findViewById(R.id.nameInput);
        dhikrTextInput = findViewById(R.id.dhikrTextInput);
        targetInput = findViewById(R.id.targetInput);
        countText = findViewById(R.id.countText);
        speedText = findViewById(R.id.speedText);
        remainingText = findViewById(R.id.remainingText);
        estimateText = findViewById(R.id.estimateText);
        finishText = findViewById(R.id.finishText);
        statusText = findViewById(R.id.statusText);
        currentTitle = findViewById(R.id.currentTitle);
        listContainer = findViewById(R.id.listContainer);

        loadAll();

        findViewById(R.id.tapArea).setOnClickListener(v -> registerTap());
        findViewById(R.id.minusButton).setOnClickListener(v -> {
            if (count > 0) { count--; saveCurrent(); updateStats(); }
        });
        findViewById(R.id.resetButton).setOnClickListener(v -> confirmReset());
        findViewById(R.id.saveButton).setOnClickListener(v -> saveCurrentFromFields());
        findViewById(R.id.addDhikrButton).setOnClickListener(v -> addNewDhikr());
        findViewById(R.id.deleteDhikrButton).setOnClickListener(v -> confirmDelete());

        handler.post(updater);
    }

    private String newId() {
        return String.valueOf(System.currentTimeMillis()) + "_" + new Random().nextInt(100000);
    }

    private void loadAll() {
        items.clear();
        String raw = prefs.getString("items_json", "");
        if (!raw.isEmpty()) {
            try {
                JSONArray a = new JSONArray(raw);
                for (int i=0;i<a.length();i++) {
                    JSONObject o=a.getJSONObject(i);
                    items.add(new Dhikr(
                        o.optString("id", newId()),
                        o.optString("name", ""),
                        o.optString("text", ""),
                        Math.max(1,o.optLong("target",1000)),
                        Math.max(0,o.optLong("count",0))
                    ));
                }
            } catch(Exception ignored) {}
        }

        // Migrate the V4 single-dzikir storage into the first saved item.
        if (items.isEmpty() && (prefs.contains("name") || prefs.contains("text") || prefs.contains("count"))) {
            items.add(new Dhikr(
                newId(),
                prefs.getString("name","Dzikir Saya"),
                prefs.getString("text",""),
                Math.max(1,prefs.getLong("target",1000)),
                Math.max(0,prefs.getLong("count",0))
            ));
            persistAll();
        }

        if (items.isEmpty()) {
            items.add(new Dhikr(newId(), "Hamdalah", "الحمد لله", 1000, 0));
            persistAll();
        }

        String sid=prefs.getString("selected_id","");
        selectedIndex=0;
        for(int i=0;i<items.size();i++) if(items.get(i).id.equals(sid)) { selectedIndex=i; break; }
        selectDhikr(selectedIndex);
        rebuildList();
    }

    private void selectDhikr(int index) {
        if(index<0 || index>=items.size()) return;
        selectedIndex=index;
        Dhikr d=items.get(index);
        count=d.count; target=d.target; lastTap=0; intervals.clear();
        nameInput.setText(d.name);
        dhikrTextInput.setText(d.text);
        targetInput.setText(String.valueOf(d.target));
        currentTitle.setText("Dzikir aktif: " + (d.name.isEmpty() ? "Tanpa nama" : d.name));
        statusText.setText("Hitungan tersimpan otomatis • " + formatNumber(d.count) + " / " + formatNumber(d.target));
        prefs.edit().putString("selected_id", d.id).apply();
        updateStats();
        rebuildList();
    }

    private void rebuildList() {
        listContainer.removeAllViews();
        for(int i=0;i<items.size();i++) {
            final int idx=i;
            Dhikr d=items.get(i);
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(14,12,14,12);
            row.setBackgroundResource(idx==selectedIndex ? R.drawable.item_selected : R.drawable.item_normal);

            TextView title=new TextView(this);
            title.setText((d.name.isEmpty() ? "Dzikir tanpa nama" : d.name));
            title.setTextSize(18);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setTextColor(getResources().getColor(R.color.dark));

            TextView prog=new TextView(this);
            prog.setText(formatNumber(d.count)+" / "+formatNumber(d.target));
            prog.setTextSize(15);
            prog.setTextColor(getResources().getColor(R.color.muted));

            row.addView(title);
            row.addView(prog);
            row.setOnClickListener(v -> selectDhikr(idx));
            listContainer.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            Space space=new Space(this);
            listContainer.addView(space,new LinearLayout.LayoutParams(1,6));
        }
    }

    private void saveCurrentFromFields() {
        if(selectedIndex<0) return;
        Dhikr d=items.get(selectedIndex);
        d.name=nameInput.getText().toString().trim();
        d.text=dhikrTextInput.getText().toString();
        readTarget();
        d.target=target;
        d.count=count;
        if(d.name.isEmpty()) d.name="Dzikir Saya";
        persistAll();
        currentTitle.setText("Dzikir aktif: " + d.name);
        statusText.setText("Perubahan tersimpan");
        rebuildList();
        updateStats();
    }

    private void saveCurrent() {
        if(selectedIndex<0) return;
        Dhikr d=items.get(selectedIndex);
        d.name=nameInput.getText().toString().trim();
        d.text=dhikrTextInput.getText().toString();
        readTarget();
        d.target=target;
        d.count=count;
        persistAll();
    }

    private void persistAll() {
        try {
            JSONArray a=new JSONArray();
            for(Dhikr d:items) {
                JSONObject o=new JSONObject();
                o.put("id",d.id); o.put("name",d.name); o.put("text",d.text);
                o.put("target",d.target); o.put("count",d.count);
                a.put(o);
            }
            prefs.edit().putString("items_json",a.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void readTarget() {
        try {
            long n=Long.parseLong(targetInput.getText().toString().trim());
            if(n>0) target=n;
        } catch(Exception ignored) {}
    }

    private void registerTap() {
        readTarget();
        if(count>=target) return;
        long now=System.currentTimeMillis();
        if(lastTap>0) {
            long d=now-lastTap;
            if(d>=150 && d<=10000) {
                intervals.addLast(d);
                while(intervals.size()>30) intervals.removeFirst();
            }
        }
        lastTap=now;
        count++;
        saveCurrent();
        try {
            ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE))
                .vibrate(android.os.VibrationEffect.createOneShot(18,45));
        } catch(Exception ignored) {}
        updateStats();
        if(selectedIndex>=0) rebuildList();
    }

    private double getKpm() {
        if(intervals.isEmpty()) return 0;
        double sum=0;
        for(long x:intervals) sum+=x;
        return 60000.0/(sum/intervals.size());
    }

    private void updateStats() {
        countText.setText(String.format(Locale.US,"%,d / %,d",count,target));
        long rem=Math.max(0,target-count);
        remainingText.setText("Sisa: "+formatNumber(rem));
        double kpm=getKpm();
        if(rem==0) {
            speedText.setText("Target tercapai");
            estimateText.setText("TARGET SELESAI");
            finishText.setText("Alhamdulillah");
        } else if(kpm<=0) {
            speedText.setText("Kecepatan: -- ketukan/menit");
            estimateText.setText("Estimasi: mulai mengetuk");
            finishText.setText("Selesai sekitar: --:--");
        } else {
            speedText.setText(String.format(Locale.US,"Kecepatan: %.1f ketukan/menit",kpm));
            long sec=Math.round((rem/kpm)*60.0);
            estimateText.setText("Estimasi tersisa: "+formatDuration(sec));
            Calendar c=Calendar.getInstance();
            c.add(Calendar.SECOND,(int)Math.min(sec,2147483647L));
            finishText.setText("Selesai sekitar: "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(c.getTime()));
        }
    }

    private String formatNumber(long n) { return String.format(Locale.US,"%,d",n); }

    private String formatDuration(long sec) {
        long h=sec/3600,m=(sec%3600)/60,s=sec%60;
        if(h>0) return h+" jam "+m+" menit";
        if(m>0) return m+" menit "+s+" detik";
        return s+" detik";
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("Reset hitungan?")
            .setMessage("Hanya hitungan dzikir aktif yang kembali ke 0. Dzikir lain tetap aman.")
            .setPositiveButton("Reset",(d,w)->{
                count=0; lastTap=0; intervals.clear(); saveCurrent(); updateStats(); rebuildList();
            })
            .setNegativeButton("Batal",null).show();
    }

    private void addNewDhikr() {
        final EditText input=new EditText(this);
        input.setHint("Nama dzikir, misalnya Sholawat");
        input.setSingleLine(true);
        input.setPadding(20,10,20,10);
        new AlertDialog.Builder(this)
            .setTitle("Tambah Dzikir")
            .setMessage("Buat tempat penyimpanan dzikir baru.")
            .setView(input)
            .setPositiveButton("Buat",(d,w)->{
                String name=input.getText().toString().trim();
                if(name.isEmpty()) name="Dzikir Baru";
                items.add(new Dhikr(newId(),name,"",1000,0));
                persistAll();
                selectDhikr(items.size()-1);
                nameInput.requestFocus();
                ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                    .showSoftInput(nameInput,InputMethodManager.SHOW_IMPLICIT);
            })
            .setNegativeButton("Batal",null).show();
    }

    private void confirmDelete() {
        if(items.size()<=1) {
            Toast.makeText(this,"Minimal harus ada satu dzikir.",Toast.LENGTH_SHORT).show();
            return;
        }
        String name=items.get(selectedIndex).name;
        new AlertDialog.Builder(this)
            .setTitle("Hapus dzikir?")
            .setMessage("Penyimpanan \""+name+"\" beserta hitungannya akan dihapus.")
            .setPositiveButton("Hapus",(d,w)->{
                items.remove(selectedIndex);
                selectedIndex=Math.max(0,selectedIndex-1);
                persistAll();
                selectDhikr(selectedIndex);
            })
            .setNegativeButton("Batal",null).show();
    }

    @Override protected void onPause() { saveCurrent(); super.onPause(); }
    @Override protected void onStop() { saveCurrent(); super.onStop(); }
    @Override protected void onDestroy() { saveCurrent(); handler.removeCallbacks(updater); super.onDestroy(); }
}
