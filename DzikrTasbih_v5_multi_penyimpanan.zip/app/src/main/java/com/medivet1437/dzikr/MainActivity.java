package com.medivet1437.dzikr;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREF="dzikr_multi";
    private android.content.SharedPreferences p;
    private ArrayList<Dhikr> items=new ArrayList<>();
    private ListView list;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> labels=new ArrayList<>();

    static class Dhikr {
        String name,text; long target,count;
        Dhikr(String n,String t,long tg,long c){name=n;text=t;target=tg;count=c;}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        p=getSharedPreferences(PREF,MODE_PRIVATE);
        list=findViewById(R.id.dhikrList);
        findViewById(R.id.addButton).setOnClickListener(v->showEditor(-1));
        load();
        refresh();
    }

    private void load(){
        items.clear();
        int n=p.getInt("n",0);
        for(int i=0;i<n;i++){
            items.add(new Dhikr(p.getString("name"+i,"Dzikir"),
                p.getString("text"+i,""),p.getLong("target"+i,1000),p.getLong("count"+i,0)));
        }
        // Import the V4 single-dhikr data if this V5 is first opened.
        if(n==0){
            android.content.SharedPreferences old=getSharedPreferences("dzikr_data",MODE_PRIVATE);
            if(old.contains("count") || old.contains("name") || old.contains("text")){
                String name=old.getString("name","Dzikir Lama");
                String text=old.getString("text","");
                long target=old.getLong("target",1000), count=old.getLong("count",0);
                items.add(new Dhikr(name,text,target,count));
                save();
            }
        }
    }

    private void save(){
        android.content.SharedPreferences.Editor e=p.edit().clear();
        e.putInt("n",items.size());
        for(int i=0;i<items.size();i++){
            Dhikr d=items.get(i);
            e.putString("name"+i,d.name).putString("text"+i,d.text)
             .putLong("target"+i,d.target).putLong("count"+i,d.count);
        }
        e.commit();
    }

    private void refresh(){
        labels.clear();
        for(Dhikr d:items){
            String s=d.name+"\n"+d.count+" / "+d.target;
            if(d.count>=d.target) s+="  ✓ SELESAI";
            labels.add(s);
        }
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,android.R.id.text1,labels){
            public View getView(int pos,View cv,android.view.ViewGroup parent){
                View v=super.getView(pos,cv,parent);
                TextView a=v.findViewById(android.R.id.text1);
                TextView b=v.findViewById(android.R.id.text2);
                a.setTextSize(19); a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
                b.setTextSize(16); return v;
            }
        };
        list.setAdapter(adapter);
        findViewById(R.id.emptyText).setVisibility(items.isEmpty()?View.VISIBLE:View.GONE);
        list.setOnItemClickListener((par,v,pos,id)->showCounter(pos));
        list.setOnItemLongClickListener((par,v,pos,id)->{
            new AlertDialog.Builder(this).setItems(new String[]{"Edit","Hapus"},(d,w)->{
                if(w==0) showEditor(pos); else confirmDelete(pos);
            }).show(); return true;
        });
    }

    private void showEditor(final int index){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        EditText name=new EditText(this); name.setHint("Nama dzikir"); box.addView(name);
        EditText text=new EditText(this); text.setHint("Teks dzikir (Arab/Indonesia)"); text.setTextSize(21); text.setGravity(Gravity.TOP|Gravity.END); text.setMinLines(2); box.addView(text);
        EditText target=new EditText(this); target.setHint("Target"); target.setInputType(2); box.addView(target);
        if(index>=0){ Dhikr d=items.get(index); name.setText(d.name); text.setText(d.text); target.setText(String.valueOf(d.target)); }
        new AlertDialog.Builder(this).setTitle(index<0?"Tambah Dzikir":"Edit Dzikir").setView(box)
          .setPositiveButton("Simpan",(d,w)->{
              long tg=1000; try{tg=Long.parseLong(target.getText().toString());}catch(Exception ignored){}
              if(tg<1)tg=1000;
              if(index<0) items.add(new Dhikr(name.getText().toString().trim().isEmpty()?"Dzikir":name.getText().toString(),text.getText().toString(),tg,0));
              else { Dhikr x=items.get(index); x.name=name.getText().toString(); x.text=text.getText().toString(); x.target=tg; }
              save(); refresh();
          }).setNegativeButton("Batal",null).show();
    }

    private void confirmDelete(int index){
        new AlertDialog.Builder(this).setTitle("Hapus dzikir?")
          .setMessage(items.get(index).name+" akan dihapus beserta hitungannya.")
          .setPositiveButton("Hapus",(d,w)->{items.remove(index);save();refresh();})
          .setNegativeButton("Batal",null).show();
    }

    private void showCounter(final int index){
        final Dhikr d=items.get(index);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,8,18,8);
        TextView title=new TextView(this); title.setText(d.name); title.setTextSize(25); title.setTypeface(null,Typeface.BOLD); title.setGravity(Gravity.CENTER); box.addView(title);
        TextView text=new TextView(this); text.setText(d.text); text.setTextSize(22); text.setGravity(Gravity.CENTER); text.setPadding(4,8,4,12); box.addView(text);
        TextView count=new TextView(this); count.setText(d.count+" / "+d.target); count.setTextSize(42); count.setGravity(Gravity.CENTER); box.addView(count);
        TextView tap=new TextView(this); tap.setText("KETUK DI SINI"); tap.setTextSize(25); tap.setTextColor(0xffffffff); tap.setGravity(Gravity.CENTER); tap.setBackgroundColor(0xff176B5B); tap.setMinHeight(220); box.addView(tap);
        TextView minus=new TextView(this); minus.setText("− 1"); minus.setTextSize(18); minus.setGravity(Gravity.CENTER); minus.setPadding(8,18,8,8); box.addView(minus);
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).setNegativeButton("TUTUP",null).setNeutralButton("RESET",null).create();
        final long[] last={0};
        tap.setOnClickListener(v->{
            if(d.count>=d.target)return;
            d.count++; count.setText(d.count+" / "+d.target); save();
            try{((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(android.os.VibrationEffect.createOneShot(18,45));}catch(Exception ignored){}
        });
        minus.setOnClickListener(v->{if(d.count>0){d.count--;count.setText(d.count+" / "+d.target);save();}});
        dlg.setOnDismissListener(x->refresh());
        dlg.show();
    }

    @Override protected void onPause(){save();super.onPause();}
    @Override protected void onStop(){save();super.onStop();}
    @Override protected void onDestroy(){save();super.onDestroy();}
}
