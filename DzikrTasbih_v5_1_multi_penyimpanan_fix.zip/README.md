# Dzikr Tasbih V5.1

Multi penyimpanan dzikir dengan penyimpanan permanen.
Setiap dzikir memiliki nama, teks, target, hitungan, dan ID sendiri.
V5.1 menyimpan seluruh daftar sebagai satu JSON sehingga menambah dzikir tidak menimpa dzikir lain.
V5 dan V4 data lama dimigrasikan otomatis bila ditemukan.
