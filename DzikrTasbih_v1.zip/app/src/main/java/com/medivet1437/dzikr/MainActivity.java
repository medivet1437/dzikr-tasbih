package com.medivet1437.dzikr;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.WindowManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private TextView countText, targetText, speedText, remainingText, estimateText, finishText;
    private long count = 0, target = 1000;
    private final ArrayDeque<Long> taps = new ArrayDeque<>();
    private final ArrayDeque<Long> intervals = new ArrayDeque<>();
    private long lastTap = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable updater = new Runnable() {
        public void run() { updateStats(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        countText = findViewById(R.id.countText);
        targetText = findViewById(R.id.targetText);
        speedText = findViewById(R.id.speedText);
        remainingText = findViewById(R.id.remainingText);
        estimateText = findViewById(R.id.estimateText);
        finishText = findViewById(R.id.finishText);

        View tap = findViewById(R.id.tapArea);
        tap.setOnClickListener(v -> registerTap());

        findViewById(R.id.minusButton).setOnClickListener(v -> {
            if (count > 0) count--;
            updateStats();
        });
        findViewById(R.id.resetButton).setOnClickListener(v -> reset());
        findViewById(R.id.targetButton).setOnClickListener(v -> chooseTarget());

        updateStats();
        handler.post(updater);
    }

    private void registerTap() {
        if (count >= target) return;
        count++;
        long now = System.currentTimeMillis();
        if (lastTap > 0) {
            long d = now - lastTap;
            if (d >= 150 && d <= 10000) {
                intervals.addLast(d);
                while (intervals.size() > 30) intervals.removeFirst();
            }
        }
        lastTap = now;
        ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(
            android.os.VibrationEffect.createOneShot(18, 45));
        updateStats();
    }

    private double getKpm() {
        if (intervals.isEmpty()) return 0;
        double sum = 0;
        for (long x : intervals) sum += x;
        double avgMs = sum / intervals.size();
        return 60000.0 / avgMs;
    }

    private void updateStats() {
        countText.setText(String.format(Locale.US, "%,d", count));
        targetText.setText("Target: " + String.format(Locale.US, "%,d", target));
        long rem = Math.max(0, target - count);
        remainingText.setText("Sisa: " + String.format(Locale.US, "%,d", rem));

        double kpm = getKpm();
        if (kpm <= 0 || rem == 0) {
            speedText.setText("Kecepatan: -- ketukan/menit");
            estimateText.setText(rem == 0 ? "TARGET TERCAPAI" : "Estimasi: mulai mengetuk");
            finishText.setText(rem == 0 ? "Selesai!" : "Selesai sekitar: --:--");
            return;
        }

        speedText.setText(String.format(Locale.US, "Kecepatan: %.1f ketukan/menit", kpm));
        long seconds = Math.round((rem / kpm) * 60.0);
        estimateText.setText("Estimasi: " + formatDuration(seconds));

        Calendar c = Calendar.getInstance();
        c.add(Calendar.SECOND, (int)Math.min(seconds, Integer.MAX_VALUE));
        finishText.setText("Selesai sekitar: " +
            new SimpleDateFormat("HH:mm", Locale.getDefault()).format(c.getTime()));
    }

    private String formatDuration(long sec) {
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        if (h > 0) return h + " jam " + m + " menit";
        if (m > 0) return m + " menit " + s + " detik";
        return s + " detik";
    }

    private void reset() {
        count = 0; lastTap = 0; intervals.clear(); updateStats();
    }

    private void chooseTarget() {
        final EditText input = new EditText(this);
        input.setInputType(2);
        input.setText(String.valueOf(target));
        new AlertDialog.Builder(this)
            .setTitle("Atur Target")
            .setView(input)
            .setPositiveButton("Simpan", (d, w) -> {
                try {
                    long n = Long.parseLong(input.getText().toString());
                    if (n > 0) { target = n; if (count > target) count = target; updateStats(); }
                } catch (Exception ignored) {}
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(updater);
        super.onDestroy();
    }
}
