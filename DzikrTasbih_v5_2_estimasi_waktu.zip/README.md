# Dzikr Tasbih V5.2

Multi penyimpanan dzikir dengan hitungan yang tetap tersimpan dan estimasi waktu berdasarkan kecepatan ketukan.

Fitur:
- Banyak dzikir dengan target masing-masing.
- Nama dan teks dzikir tersimpan.
- Hitungan tiap dzikir tersimpan setelah aplikasi ditutup.
- Estimasi waktu sisa berdasarkan rata-rata interval ketukan.
- Waktu saat aplikasi ditutup/istirahat panjang tidak dihitung.
