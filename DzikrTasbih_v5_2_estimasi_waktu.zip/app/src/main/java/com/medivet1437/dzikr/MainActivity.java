package com.medivet1437.dzikr;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREF="dzikr_v51";
    private static final String KEY="items_json";
    private SharedPreferences p;
    private final ArrayList<Dhikr> items=new ArrayList<>();
    private ListView list;
    private ArrayAdapter<String> adapter;
    private final ArrayList<String> labels=new ArrayList<>();

    static class Dhikr {
        String id,name,text;
        long target,count;
        long elapsedMs;       // active tapping time accumulated across sessions
        long tapIntervals;    // number of measured intervals between taps
        long lastTapMs;       // last tap timestamp, not counted while app is closed

        Dhikr(String id,String n,String t,long tg,long c){
            this(id,n,t,tg,c,0,0,0);
        }

        Dhikr(String id,String n,String t,long tg,long c,long e,long ti,long lt){
            this.id=id; name=n; text=t; target=tg; count=c;
            elapsedMs=Math.max(0,e);
            tapIntervals=Math.max(0,ti);
            lastTapMs=Math.max(0,lt);
        }
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        p=getSharedPreferences(PREF,MODE_PRIVATE);
        list=findViewById(R.id.dhikrList);
        findViewById(R.id.addButton).setOnClickListener(v->showEditor(-1));
        load();
        refresh();
    }

    private String newId(){
        return UUID.randomUUID().toString();
    }

    private void load(){
        items.clear();

        // Primary V5.1 storage: one JSON document, so adding one item can never
        // overwrite another item because of reused SharedPreferences keys.
        String json=p.getString(KEY,null);
        if(json!=null && !json.isEmpty()){
            try{
                JSONArray a=new JSONArray(json);
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);
                    items.add(new Dhikr(
                        o.optString("id",newId()),
                        o.optString("name","Dzikir"),
                        o.optString("text",""),
                        Math.max(1,o.optLong("target",1000)),
                        Math.max(0,o.optLong("count",0)),
                        Math.max(0,o.optLong("elapsedMs",0)),
                        Math.max(0,o.optLong("tapIntervals",0)),
                        Math.max(0,o.optLong("lastTapMs",0))
                    ));
                }
                return;
            }catch(Exception ignored){}
        }

        // Migrate the V5 indexed storage if it exists.
        SharedPreferences oldV5=getSharedPreferences("dzikr_multi",MODE_PRIVATE);
        int n=oldV5.getInt("n",0);
        if(n>0){
            for(int i=0;i<n;i++){
                items.add(new Dhikr(
                    newId(),
                    oldV5.getString("name"+i,"Dzikir"),
                    oldV5.getString("text"+i,""),
                    Math.max(1,oldV5.getLong("target"+i,1000)),
                    Math.max(0,oldV5.getLong("count"+i,0))
                ));
            }
            save();
            return;
        }

        // Migrate the original V4 single-dhikr storage once.
        SharedPreferences old=getSharedPreferences("dzikr_data",MODE_PRIVATE);
        if(old.contains("count") || old.contains("name") || old.contains("text")){
            items.add(new Dhikr(
                newId(),
                old.getString("name","Dzikir Lama"),
                old.getString("text",""),
                Math.max(1,old.getLong("target",1000)),
                Math.max(0,old.getLong("count",0))
            ));
            save();
        }
    }

    private void save(){
        JSONArray a=new JSONArray();
        try{
            for(Dhikr d:items){
                JSONObject o=new JSONObject();
                o.put("id",d.id);
                o.put("name",d.name);
                o.put("text",d.text);
                o.put("target",d.target);
                o.put("count",d.count);
                o.put("elapsedMs",d.elapsedMs);
                o.put("tapIntervals",d.tapIntervals);
                // Do not use lastTapMs after a long pause as active tapping time.
                o.put("lastTapMs",d.lastTapMs);
                a.put(o);
            }
            p.edit().putString(KEY,a.toString()).commit();
        }catch(Exception ignored){}
    }

    private void refresh(){
        labels.clear();
        for(Dhikr d:items){
            String s=d.name+"\n"+d.count+" / "+d.target;
            if(d.count>=d.target) s+="  ✓ SELESAI";
            labels.add(s);
        }
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,
                android.R.id.text1,labels){
            @Override public View getView(int pos,View cv,ViewGroup parent){
                View v=super.getView(pos,cv,parent);
                TextView a=v.findViewById(android.R.id.text1);
                TextView b=v.findViewById(android.R.id.text2);
                a.setTextSize(19);
                a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
                b.setTextSize(16);
                return v;
            }
        };
        list.setAdapter(adapter);
        findViewById(R.id.emptyText).setVisibility(
            items.isEmpty()?View.VISIBLE:View.GONE
        );

        list.setOnItemClickListener((par,v,pos,id)->showCounter(pos));
        list.setOnItemLongClickListener((par,v,pos,id)->{
            new AlertDialog.Builder(this)
                .setItems(new String[]{"Edit","Hapus"},(d,w)->{
                    if(w==0) showEditor(pos);
                    else confirmDelete(pos);
                }).show();
            return true;
        });
    }

    private void showEditor(final int index){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(30,10,30,0);

        EditText name=new EditText(this);
        name.setHint("Nama dzikir");
        box.addView(name);

        EditText text=new EditText(this);
        text.setHint("Teks dzikir (Arab/Indonesia)");
        text.setTextSize(21);
        text.setGravity(Gravity.TOP|Gravity.END);
        text.setMinLines(2);
        box.addView(text);

        EditText target=new EditText(this);
        target.setHint("Target");
        target.setInputType(2);
        box.addView(target);

        if(index>=0){
            Dhikr d=items.get(index);
            name.setText(d.name);
            text.setText(d.text);
            target.setText(String.valueOf(d.target));
        }

        new AlertDialog.Builder(this)
            .setTitle(index<0?"Tambah Dzikir":"Edit Dzikir")
            .setView(box)
            .setPositiveButton("Simpan",(d,w)->{
                String nm=name.getText().toString().trim();
                if(nm.isEmpty()) nm="Dzikir";
                String tx=text.getText().toString();
                long tg=1000;
                try{ tg=Long.parseLong(target.getText().toString().trim()); }
                catch(Exception ignored){}
                if(tg<1) tg=1000;

                if(index<0){
                    // Always append a brand-new record with a unique ID.
                    items.add(new Dhikr(newId(),nm,tx,tg,0));
                }else{
                    Dhikr x=items.get(index);
                    x.name=nm;
                    x.text=tx;
                    x.target=tg;
                    if(x.count>x.target) x.count=x.target;
                }
                save();
                refresh();
            })
            .setNegativeButton("Batal",null)
            .show();
    }

    private void confirmDelete(int index){
        new AlertDialog.Builder(this)
            .setTitle("Hapus dzikir?")
            .setMessage(items.get(index).name+" akan dihapus beserta hitungannya.")
            .setPositiveButton("Hapus",(d,w)->{
                items.remove(index);
                save();
                refresh();
            })
            .setNegativeButton("Batal",null)
            .show();
    }

    private String formatDuration(long ms){
        long totalSec=Math.max(0,Math.round(ms/1000.0));
        long h=totalSec/3600;
        long m=(totalSec%3600)/60;
        long s=totalSec%60;
        if(h>0) return h+" jam "+m+" menit";
        if(m>0) return m+" menit "+s+" detik";
        return s+" detik";
    }

    private String estimate(Dhikr d){
        long remaining=Math.max(0,d.target-d.count);
        if(remaining<=0) return "Selesai ✓";
        if(d.tapIntervals<=0 || d.elapsedMs<=0) return "Estimasi waktu: menunggu 2 hitungan...";
        double avgMs=(double)d.elapsedMs/(double)d.tapIntervals;
        return "Estimasi waktu: "+formatDuration((long)(remaining*avgMs));
    }

    private void showCounter(final int index){
        final Dhikr d=items.get(index);

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18,8,18,8);

        TextView title=new TextView(this);
        title.setText(d.name);
        title.setTextSize(25);
        title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView text=new TextView(this);
        text.setText(d.text);
        text.setTextSize(22);
        text.setGravity(Gravity.CENTER);
        text.setPadding(4,8,4,12);
        box.addView(text);

        TextView count=new TextView(this);
        count.setText(d.count+" / "+d.target);
        count.setTextSize(42);
        count.setGravity(Gravity.CENTER);
        box.addView(count);

        TextView estimate=new TextView(this);
        estimate.setText(estimate(d));
        estimate.setTextSize(17);
        estimate.setGravity(Gravity.CENTER);
        estimate.setPadding(4,0,4,12);
        box.addView(estimate);

        TextView tap=new TextView(this);
        tap.setText("KETUK DI SINI");
        tap.setTextSize(25);
        tap.setTextColor(0xffffffff);
        tap.setGravity(Gravity.CENTER);
        tap.setBackgroundColor(0xff176B5B);
        tap.setMinHeight(220);
        box.addView(tap);

        TextView minus=new TextView(this);
        minus.setText("− 1");
        minus.setTextSize(18);
        minus.setGravity(Gravity.CENTER);
        minus.setPadding(8,18,8,8);
        box.addView(minus);

        AlertDialog dlg=new AlertDialog.Builder(this)
            .setView(box)
            .setNegativeButton("TUTUP",null)
            .setNeutralButton("RESET",null)
            .create();

        tap.setOnClickListener(v->{
            if(d.count>=d.target) return;

            long now=System.currentTimeMillis();
            // Count only normal tapping gaps (up to 5 minutes). Time while
            // the app is closed or the user pauses for a long time is excluded.
            if(d.lastTapMs>0){
                long gap=now-d.lastTapMs;
                if(gap>=80 && gap<=5*60*1000L){
                    d.elapsedMs += gap;
                    d.tapIntervals++;
                }
            }
            d.lastTapMs=now;
            d.count++;
            count.setText(d.count+" / "+d.target);
            estimate.setText(estimate(d));
            save();
            try{
                ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE))
                    .vibrate(android.os.VibrationEffect.createOneShot(18,45));
            }catch(Exception ignored){}
        });

        minus.setOnClickListener(v->{
            if(d.count>0){
                d.count--;
                count.setText(d.count+" / "+d.target);
                estimate.setText(estimate(d));
                save();
            }
        });

        dlg.setOnShowListener(x->{
            Button reset=dlg.getButton(AlertDialog.BUTTON_NEUTRAL);
            if(reset!=null){
                reset.setOnClickListener(v->{
                    d.count=0;
                    d.elapsedMs=0;
                    d.tapIntervals=0;
                    d.lastTapMs=0;
                    count.setText("0 / "+d.target);
                    estimate.setText(estimate(d));
                    save();
                });
            }
        });

        dlg.setOnDismissListener(x->refresh());
        dlg.show();
    }

    @Override protected void onPause(){save();super.onPause();}
    @Override protected void onStop(){save();super.onStop();}
    @Override protected void onDestroy(){save();super.onDestroy();}
}
